(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 8);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/regenerator");

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/helpers/asyncToGenerator");

/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = require("path");

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("request-promise-native");

/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = require("lodash");

/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = require("sleep");

/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = require("dotenv");

/***/ }),
/* 7 */,
/* 8 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _stringify = __webpack_require__(9);

var _stringify2 = _interopRequireDefault(_stringify);

var _regenerator = __webpack_require__(0);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = __webpack_require__(1);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _promise = __webpack_require__(10);

var _promise2 = _interopRequireDefault(_promise);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var Twitter = __webpack_require__(11),
    path = __webpack_require__(2),
    rp = __webpack_require__(3),
    _ = __webpack_require__(4),
    sleep = __webpack_require__(5);

// setup environmental var
var envPath = path.join(process.cwd(), '.env');
__webpack_require__(6).config(envPath);

var CHATWORK_TOKEN = process.env.CHATWORK_TOKEN
// , ROOM_ID = process.env.ROOM_ID
,
    ROOM_ID = process.env.TEST_ROOM_ID;

var TWCLIENT = new Twitter({
  consumer_key: process.env.CONSUMER_KEY,
  consumer_secret: process.env.CONSUMER_SECRET,
  access_token_key: process.env.ACCESS_TOKEN_KEY,
  access_token_secret: process.env.ACCESS_TOKEN_SECRET
});

var CHATWORK_POST_ENDPOINT = 'https://api.chatwork.com/v2/rooms/' + ROOM_ID + '/messages',
    CHATWORK_UNREAD_ENDPOINT = 'https://api.chatwork.com/v2/rooms/' + ROOM_ID + '/messages/unread';

var SCREEN_NAMES = ['hillbig', 'ymatsuo', 'hamadakoichi'];

var extractLatestTweets = function extractLatestTweets(tweets) {
  var now = new Date(),
      oneHourAgo = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours() - 1, now.getMinutes());
  var latestTweets = _.filter(tweets, function (element) {
    return oneHourAgo < new Date(element['created_at']);
  });

  return latestTweets;
};

var formatChatworkStyle = function formatChatworkStyle(tweets, screenName) {
  var formattedText = _.map(tweets, function (element) {
    var body = element['text'];
    var id = element['id_str'];
    var messageBody = '[info][title]' + screenName + ' on Twitter[/title]' + body + '\r\nhttps://twitter.com/hillbig/status/' + id + ' [/info]';
    return messageBody;
  }).join("");
  return formattedText;
};

var searchLatestTweets = function searchLatestTweets(screenName) {
  var params = {
    screen_name: screenName
  };
  return new _promise2.default(function (resolve) {
    TWCLIENT.get('statuses/user_timeline', params).then(function (tweets) {
      var latestTweets = extractLatestTweets(tweets);
      resolve(latestTweets);
    });
  });
};

var NotifyToChatwork = function NotifyToChatwork(screenName) {
  return new _promise2.default(function (resolve) {
    (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee() {
      var tweets, messageBody, options, response, messageId;
      return _regenerator2.default.wrap(function _callee$(_context) {
        while (1) {
          switch (_context.prev = _context.next) {
            case 0:
              _context.next = 2;
              return searchLatestTweets(screenName);

            case 2:
              tweets = _context.sent;
              messageBody = formatChatworkStyle(tweets, screenName);
              options = void 0, response = void 0;

              if (messageBody) {
                _context.next = 7;
                break;
              }

              return _context.abrupt('return');

            case 7:
              options = {
                method: 'POST',
                uri: CHATWORK_POST_ENDPOINT,
                form: {
                  body: messageBody
                },
                headers: {
                  'User-Agent': 'serverless-bot',
                  'X-ChatWorkToken': CHATWORK_TOKEN
                },
                json: true
              };
              _context.next = 10;
              return rp(options);

            case 10:
              response = _context.sent;
              messageId = response['message_id'];

              resolve(messageId);

            case 13:
            case 'end':
              return _context.stop();
          }
        }
      }, _callee, undefined);
    }))();
  });
};

var markUnRead = function markUnRead(messageId) {
  (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee2() {
    var options;
    return _regenerator2.default.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            _context2.next = 2;
            return sleep.sleep(10);

          case 2:
            options = {
              method: 'PUT',
              uri: CHATWORK_UNREAD_ENDPOINT,
              form: {
                message_id: messageId
              },
              headers: {
                'User-Agent': 'serverless-bot',
                'X-ChatWorkToken': CHATWORK_TOKEN
              },
              json: true
            };
            _context2.next = 5;
            return rp(options);

          case 5:
            response = _context2.sent;

          case 6:
          case 'end':
            return _context2.stop();
        }
      }
    }, _callee2, undefined);
  }))();
};

module.exports.execute = function (event, context, callback) {
  var promises = [];
  var promise = void 0;
  SCREEN_NAMES.forEach(function (screenName) {
    promise = NotifyToChatwork(screenName);
    promises.push(promise);
  });
  _promise2.default.all(promises).then(function (messageIds) {
    if (!_.isEmpty(messageIds)) {
      console.log(messageIds);
      markUnRead(_.min(messageIds));
    }

    var response = {
      statusCode: 200,
      body: (0, _stringify2.default)({
        message: 'success🍺',
        input: event
      })
    };
    callback(null, response);
  });
};

module.exports.hillbig = function (event, context, callback) {
  var params = { screen_name: 'hillbig' };
  client.get('statuses/user_timeline', params).then(function (tweets) {
    var tweetFormatted = extractLatestTweets(tweets),
        url = 'https://api.chatwork.com/v2/rooms/' + room_id + '/messages';
    request.post(url).field('body', tweetFormatted).set('X-ChatWorkToken', c_token).end(function (err, res) {
      console.log(res);
    });
  });
  var response = {
    statusCode: 200,
    body: (0, _stringify2.default)({
      message: 'its dummy response',
      input: event
    })
  };
  callback(null, response);
};

/***/ }),
/* 9 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/core-js/json/stringify");

/***/ }),
/* 10 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/core-js/promise");

/***/ }),
/* 11 */
/***/ (function(module, exports) {

module.exports = require("twitter");

/***/ })
/******/ ])));