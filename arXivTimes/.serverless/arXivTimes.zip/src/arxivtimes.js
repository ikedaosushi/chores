(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 7);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/regenerator");

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("babel-runtime/helpers/asyncToGenerator");

/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = require("path");

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("request-promise-native");

/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = require("lodash");

/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = require("sleep");

/***/ }),
/* 6 */
/***/ (function(module, exports) {

module.exports = require("dotenv");

/***/ }),
/* 7 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _regenerator = __webpack_require__(0);

var _regenerator2 = _interopRequireDefault(_regenerator);

var _asyncToGenerator2 = __webpack_require__(1);

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

var path = __webpack_require__(2),
    rp = __webpack_require__(3),
    _ = __webpack_require__(4),
    sleep = __webpack_require__(5);

// setup environmental var
var envPath = path.join(process.cwd(), '.env');
__webpack_require__(6).config(envPath);

var CHATWORK_TOKEN = process.env.CHATWORK_TOKEN
// , ROOM_ID = process.env.ROOM_ID
,
    ROOM_ID = process.env.TEST_ROOM_ID;

var GITHUB_ENDPOINT = 'https://api.github.com/repos/arXivTimes/arXivTimes/issues',
    CHATWORK_POST_ENDPOINT = 'https://api.chatwork.com/v2/rooms/' + ROOM_ID + '/messages',
    CHATWORK_UNREAD_ENDPOINT = 'https://api.chatwork.com/v2/rooms/' + ROOM_ID + '/messages/unread';

function formatText(article) {
    var template = _.template('[info][title]<%= title %>[/title]<%= wrap %>\r\n<%= url %>[/info]'),
        title = article['title'],
        url = article['html_url'],
        wrap = article['body'].match(/## 一言[\s\S]*### 論文/)[0].replace('## 一言でいうと\r\n', '').replace(/^\r\n/g, '').replace('\r\n\r\n### 論文', ''),
        formattedText = template({
        'title': title,
        'wrap': wrap,
        'url': url
    });
    return formattedText;
}

module.exports.execute = function (event, context, callback) {
    var now = new Date(),
        oneHourAgo = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours() - 2, now.getMinutes());
    var options = void 0,
        response = void 0;
    (0, _asyncToGenerator3.default)( /*#__PURE__*/_regenerator2.default.mark(function _callee() {
        var articles, newArticles, messageBody, messageId;
        return _regenerator2.default.wrap(function _callee$(_context) {
            while (1) {
                switch (_context.prev = _context.next) {
                    case 0:
                        options = {
                            method: 'GET',
                            uri: GITHUB_ENDPOINT,
                            json: true,
                            headers: {
                                'User-Agent': 'serverless-bot'
                            }
                        };
                        _context.next = 3;
                        return rp(options);

                    case 3:
                        articles = _context.sent;
                        newArticles = _.filter(articles, function (article, _) {
                            var date = Date.parse(article['created_at']);
                            return oneHourAgo < date;
                        });
                        messageBody = newArticles.map(function (article, _) {
                            return formatText(article);
                        }).join("");

                        if (messageBody) {
                            _context.next = 8;
                            break;
                        }

                        return _context.abrupt('return');

                    case 8:
                        ;

                        options = {
                            method: 'POST',
                            uri: CHATWORK_POST_ENDPOINT,
                            form: {
                                body: messageBody
                            },
                            headers: {
                                'User-Agent': 'serverless-bot',
                                'X-ChatWorkToken': CHATWORK_TOKEN
                            },
                            json: true
                        };
                        _context.next = 12;
                        return rp(options);

                    case 12:
                        response = _context.sent;
                        messageId = response['message_id'];

                        // Wait 10 seconds because it needs some seconds until chatwork reflect post result 

                        _context.next = 16;
                        return sleep.sleep(10);

                    case 16:

                        options = {
                            method: 'PUT',
                            uri: CHATWORK_UNREAD_ENDPOINT,
                            form: {
                                message_id: messageId
                            },
                            headers: {
                                'User-Agent': 'serverless-bot',
                                'X-ChatWorkToken': CHATWORK_TOKEN
                            },
                            json: true
                        };
                        _context.next = 19;
                        return rp(options);

                    case 19:
                        response = _context.sent;

                        response = {
                            statusCode: 200,
                            body: 'Sucess🍺'
                        };
                        callback(null, response);

                    case 22:
                    case 'end':
                        return _context.stop();
                }
            }
        }, _callee, undefined);
    }))();
};

/***/ })
/******/ ])));